#ifndef STATIC_LINK
#define IMPLEMENT_API

#include <hx/CFFI.h>
#endif
