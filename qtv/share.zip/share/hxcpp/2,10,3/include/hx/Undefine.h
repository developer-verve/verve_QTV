#ifndef HX_UNDEFINE_H
#define HX_UNDEFINE_H


#undef INT_MIN
#undef INT_MAX
#undef INT8_MIN
#undef INT8_MAX
#undef UINT8_MAX
#undef INT16_MIN
#undef INT16_MAX
#undef UINT16_MAX
#undef INT32_MIN
#undef INT32_MAX
#undef UINT32_MAX



#endif
