#ifndef HX_INDEX_REF_H
#define HX_INDEX_REF_H

namespace hx
{

}

#endif
